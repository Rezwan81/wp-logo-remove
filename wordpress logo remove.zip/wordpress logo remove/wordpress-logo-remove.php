<?php
/**
 * @package Wordpress logo remove
 */
/*

Plugin Name: Wordpress logo remove
Plugin URI: https://devles.com/
Description: This is wordpress admin logo removebal plugin
Author: Rezwan Shiblu
Author URI: https://devles.com/
Version: 1.0
License: GPLv2 or later
Text Domain: Wordpress logo remove
*/


/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Rezwan,Sylhet, Bangladesh.

Copyright 2020.
*/


//update toolbar
function update_adminbar($wp_adminbar){
	//remove unnecessary items
$wp_adminbar->remove_node('wp-logo');
$wp_adminbar->remove_node('customize');
$wp_adminbar->remove_node('customize');
$wp_adminbar->remove_node('thegem-theme-options');
$wp_adminbar->remove_node('thegem-support-center');
$wp_adminbar->remove_node('thegem-documentation');	
}

add_action('admin_bar_menu', 'update_adminbar', 999);




